from __future__ import annotations

import os
import time
from pathlib import Path

from fastapi.testclient import TestClient


os.environ["OFFLINE_DEBUGGER_DISABLE_MODEL"] = "1"

import app  # noqa: E402


client = TestClient(app.app)


def test_health_endpoint() -> None:
    response = client.get("/health")
    assert response.status_code == 200
    payload = response.json()
    assert payload["status"] == "online"
    assert "workspace_root" in payload
    assert "uptime_seconds" in payload
    assert "frontend_ready" in payload
    assert "x-request-id" in response.headers
    assert response.headers.get("x-content-type-options") == "nosniff"
    assert response.headers.get("x-frame-options") == "DENY"


def test_rate_limit_enforced() -> None:
    original_limit = app.rate_limiter.limit_per_minute
    try:
        app.rate_limiter.limit_per_minute = 1
        app.rate_limiter._counter.clear()
        app.rate_limiter._current_window = int(time.time() // 60)

        first = client.get("/scan_project")
        second = client.get("/scan_project")

        assert first.status_code == 200
        assert second.status_code == 429
        assert "request_id" in second.json()
        assert second.headers.get("x-content-type-options") == "nosniff"
    finally:
        app.rate_limiter.limit_per_minute = original_limit
        app.rate_limiter._counter.clear()
        app.rate_limiter._current_window = int(time.time() // 60)


def test_debug_rejects_paths_outside_workspace() -> None:
    response = client.post("/debug", json={"file_path": "..\\..\\Windows\\System32\\drivers\\etc\\hosts"})
    assert response.status_code == 403


def test_upload_rejects_non_python_extension() -> None:
    response = client.post(
        "/upload",
        files={"file": ("payload.txt", b"print('x')", "text/plain")},
    )
    assert response.status_code == 400
    assert "Only .py uploads are supported." in response.text


def test_apply_fix_creates_fixed_file() -> None:
    workspace = Path(app.WORKSPACE_ROOT)
    target = workspace / "_pytest_sample.py"
    fixed_target = workspace / "fixed__pytest_sample.py"

    target.write_text("value = 1\nprint(value)\n", encoding="utf-8")
    try:
        response = client.post(
            "/apply_fix",
            json={
                "file_path": str(target),
                "fixed_code": "```python\nvalue = 2\nprint(value)\n```",
            },
        )
        assert response.status_code == 200
        payload = response.json()
        assert Path(payload["path"]).exists()
        assert fixed_target.exists()
        assert "value = 2" in fixed_target.read_text(encoding="utf-8")
    finally:
        target.unlink(missing_ok=True)
        fixed_target.unlink(missing_ok=True)
