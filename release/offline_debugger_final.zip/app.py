from __future__ import annotations

import asyncio
import difflib
import hashlib
import logging
import os
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import uuid
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, Optional

from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict, Field
from starlette.responses import Response

sys.path.append(os.path.join(os.path.dirname(__file__), "src"))

from agents import DebuggingAgents
from rag_engine import LocalRAGEngine
from Scanner import CodeScanner


def _env_int(name: str, default: int, minimum: int = 1) -> int:
    raw = os.getenv(name)
    if raw is None:
        return default
    try:
        value = int(raw)
    except ValueError:
        return default
    return max(value, minimum)


def _env_csv(name: str, default: list[str]) -> list[str]:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    return [item.strip() for item in raw.split(",") if item.strip()]


PROJECT_ROOT = Path(__file__).resolve().parent
WORKSPACE_ROOT = Path(os.getenv("OFFLINE_DEBUGGER_WORKSPACE_ROOT", str(PROJECT_ROOT))).resolve()
UPLOAD_DIR = Path(os.getenv("OFFLINE_DEBUGGER_UPLOAD_DIR", str(WORKSPACE_ROOT / "uploads"))).resolve()
MODEL_PATH = os.getenv("OFFLINE_DEBUGGER_MODEL_PATH", "models/qwen2.5-coder-1.5b-instruct-q4_k_m.gguf")
EXEC_TIMEOUT_SECONDS = _env_int("OFFLINE_DEBUGGER_EXEC_TIMEOUT_SECONDS", 10, minimum=1)
THREAD_POOL_WORKERS = _env_int("OFFLINE_DEBUGGER_THREAD_POOL_WORKERS", 6, minimum=2)
MAX_UPLOAD_BYTES = _env_int("OFFLINE_DEBUGGER_MAX_UPLOAD_BYTES", 2 * 1024 * 1024, minimum=1024)
MAX_SNIPPET_CHARS = _env_int("OFFLINE_DEBUGGER_MAX_SNIPPET_CHARS", 200_000, minimum=1000)
CACHE_TTL_SECONDS = _env_int("OFFLINE_DEBUGGER_CACHE_TTL_SECONDS", 300, minimum=10)
CACHE_MAX_ENTRIES = _env_int("OFFLINE_DEBUGGER_CACHE_MAX_ENTRIES", 256, minimum=16)
ALLOWED_ORIGINS = _env_csv(
    "OFFLINE_DEBUGGER_ALLOWED_ORIGINS",
    [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:8000",
        "http://127.0.0.1:8000",
    ],
)
HOST = os.getenv("OFFLINE_DEBUGGER_HOST", "0.0.0.0")
PORT = _env_int("OFFLINE_DEBUGGER_PORT", 8000, minimum=1)
LOG_LEVEL = os.getenv("OFFLINE_DEBUGGER_LOG_LEVEL", "INFO").upper()
RATE_LIMIT_PER_MINUTE = _env_int("OFFLINE_DEBUGGER_RATE_LIMIT_PER_MINUTE", 120, minimum=10)


logging.basicConfig(
    level=getattr(logging, LOG_LEVEL, logging.INFO),
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)
logger = logging.getLogger("offline_debugger")
PROCESS_START_TIME = time.time()


if WORKSPACE_ROOT != PROJECT_ROOT and not WORKSPACE_ROOT.exists():
    raise RuntimeError(f"Configured workspace does not exist: {WORKSPACE_ROOT}")

UPLOAD_DIR.mkdir(parents=True, exist_ok=True)


class TimedResponseCache:
    def __init__(self, ttl_seconds: int, max_entries: int):
        self.ttl_seconds = ttl_seconds
        self.max_entries = max_entries
        self._lock = threading.Lock()
        self._items: "OrderedDict[str, tuple[float, DebugResponse]]" = OrderedDict()

    def get(self, key: str) -> Optional["DebugResponse"]:
        now = time.monotonic()
        with self._lock:
            item = self._items.get(key)
            if not item:
                return None

            expires_at, value = item
            if expires_at < now:
                self._items.pop(key, None)
                return None

            # Mark as recently used.
            self._items.move_to_end(key, last=True)
            return value

    def set(self, key: str, value: "DebugResponse") -> None:
        expires_at = time.monotonic() + self.ttl_seconds
        with self._lock:
            self._items[key] = (expires_at, value)
            self._items.move_to_end(key, last=True)

            while len(self._items) > self.max_entries:
                self._items.popitem(last=False)


class InMemoryRateLimiter:
    """Simple fixed-window in-memory rate limiter by client host."""

    def __init__(self, limit_per_minute: int):
        self.limit_per_minute = limit_per_minute
        self._lock = threading.Lock()
        self._counter: dict[tuple[str, int], int] = {}
        self._current_window = int(time.time() // 60)

    def allow(self, client_id: str) -> bool:
        now_window = int(time.time() // 60)
        with self._lock:
            if now_window != self._current_window:
                self._counter.clear()
                self._current_window = now_window

            key = (client_id, now_window)
            current = self._counter.get(key, 0)
            if current >= self.limit_per_minute:
                return False
            self._counter[key] = current + 1
            return True


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class DebugRequest(StrictModel):
    file_path: str = Field(min_length=1, max_length=4096)


class SnippetRequest(StrictModel):
    code: str = Field(min_length=1, max_length=MAX_SNIPPET_CHARS)


class DiffRequest(StrictModel):
    original: str
    fixed: str


class ComplexityRequest(StrictModel):
    code: str = Field(min_length=1, max_length=MAX_SNIPPET_CHARS)


class ApplyFixRequest(StrictModel):
    file_path: str = Field(min_length=1, max_length=4096)
    fixed_code: str = Field(min_length=1, max_length=MAX_SNIPPET_CHARS)


class DebugResponse(BaseModel):
    error: Optional[str] = None
    analysis: Optional[str] = None
    explanation: Optional[str] = None
    verification: Optional[str] = None
    fixed_code: Optional[str] = None
    severity: Optional[str] = None
    confidence: Optional[int] = None
    complexity: Optional[dict[str, Any]] = None
    security_audit: Optional[dict[str, Any]] = None
    topology: Optional[dict[str, Any]] = None
    metrics: Optional[dict[str, float]] = None
    total_time: Optional[float] = None
    source_path: Optional[str] = None
    source_code: Optional[str] = None
    success: bool


@asynccontextmanager
async def lifespan(_: FastAPI):
    logger.info(
        "startup workspace_root=%s upload_dir=%s model_path=%s rate_limit_per_minute=%s",
        WORKSPACE_ROOT,
        UPLOAD_DIR,
        MODEL_PATH,
        RATE_LIMIT_PER_MINUTE,
    )
    try:
        yield
    finally:
        try:
            executor.shutdown(wait=False, cancel_futures=True)
        except TypeError:
            executor.shutdown(wait=False)


app = FastAPI(
    title="Offline Debugger API",
    version="6.0.0",
    description="Secure, local-first debugging API with agentic repair pipeline.",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(GZipMiddleware, minimum_size=1024)

RATE_LIMITED_PREFIXES = {
    "/debug",
    "/debug_snippet",
    "/upload",
    "/apply_fix",
    "/analyze_complexity",
    "/scan_project",
    "/diff",
}
rate_limiter = InMemoryRateLimiter(limit_per_minute=RATE_LIMIT_PER_MINUTE)


def _is_rate_limited_path(path: str) -> bool:
    return any(path.startswith(prefix) for prefix in RATE_LIMITED_PREFIXES)


def _apply_common_response_headers(
    response: Response,
    request_id: str,
    elapsed_ms: float,
    path: str,
) -> None:
    response.headers["X-Request-ID"] = request_id
    response.headers["X-Process-Time-Ms"] = f"{elapsed_ms:.2f}"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    if path.startswith("/debug") or path.startswith("/upload") or path.startswith("/apply_fix"):
        response.headers["Cache-Control"] = "no-store"


@app.middleware("http")
async def request_context_middleware(request: Request, call_next):
    request_id = str(uuid.uuid4())
    request.state.request_id = request_id
    started = time.perf_counter()
    path = request.url.path

    if _is_rate_limited_path(path):
        client_host = request.client.host if request.client and request.client.host else "unknown"
        if not rate_limiter.allow(client_host):
            elapsed_ms = (time.perf_counter() - started) * 1000
            response = JSONResponse(
                status_code=429,
                content={
                    "detail": "Rate limit exceeded. Please retry later.",
                    "request_id": request_id,
                },
            )
            _apply_common_response_headers(response, request_id, elapsed_ms, path)
            return response

    response = await call_next(request)
    elapsed_ms = (time.perf_counter() - started) * 1000

    _apply_common_response_headers(response, request_id, elapsed_ms, path)

    logger.info(
        "request_id=%s method=%s path=%s status=%s duration_ms=%.2f",
        request_id,
        request.method,
        path,
        response.status_code,
        elapsed_ms,
    )
    return response


scanner = CodeScanner(str(WORKSPACE_ROOT))
rag = LocalRAGEngine(data_dir="knowledge_base")
agents = DebuggingAgents(model_path=MODEL_PATH)
executor = ThreadPoolExecutor(max_workers=THREAD_POOL_WORKERS)
debug_cache = TimedResponseCache(ttl_seconds=CACHE_TTL_SECONDS, max_entries=CACHE_MAX_ENTRIES)


def _safe_resolve_workspace_path(
    raw_path: str,
    *,
    must_exist: bool,
    enforce_python: bool = True,
) -> Path:
    candidate_raw = raw_path.strip()
    if not candidate_raw:
        raise HTTPException(status_code=400, detail="file_path is required.")

    path_obj = Path(candidate_raw)
    candidate = path_obj if path_obj.is_absolute() else WORKSPACE_ROOT / path_obj
    resolved = candidate.resolve()

    try:
        resolved.relative_to(WORKSPACE_ROOT)
    except ValueError as exc:
        raise HTTPException(status_code=403, detail="Path outside workspace is not allowed.") from exc

    if must_exist and not resolved.exists():
        raise HTTPException(status_code=404, detail="File not found.")

    if must_exist and resolved.is_dir():
        raise HTTPException(status_code=400, detail="Expected a file path, got a directory.")

    if enforce_python and resolved.suffix.lower() != ".py":
        raise HTTPException(status_code=400, detail="Only .py files are supported.")

    return resolved


def _safe_upload_name(filename: str | None) -> str:
    safe_name = Path(filename or "").name.strip()
    if safe_name in {"", ".", ".."}:
        raise HTTPException(status_code=400, detail="Invalid upload filename.")
    if not safe_name.lower().endswith(".py"):
        raise HTTPException(status_code=400, detail="Only .py uploads are supported.")
    return safe_name


def _extract_error_line(stderr: str, returncode: int) -> str:
    if not stderr.strip():
        return f"RuntimeError: Script exited with code {returncode}."
    lines = [line.strip() for line in stderr.splitlines() if line.strip()]
    return lines[-1] if lines else f"RuntimeError: Script exited with code {returncode}."


def run_target_code(file_path: Path) -> Optional[str]:
    try:
        result = subprocess.run(
            [sys.executable, str(file_path)],
            capture_output=True,
            text=True,
            timeout=EXEC_TIMEOUT_SECONDS,
            cwd=str(file_path.parent),
        )
        if result.returncode == 0:
            return None
        stderr = result.stderr or result.stdout or ""
        return _extract_error_line(stderr, result.returncode)
    except subprocess.TimeoutExpired:
        return "TimeoutError: Script execution exceeded timeout (possible infinite loop)."
    except Exception as exc:
        return str(exc)


async def run_in_executor(func, *args):
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(executor, func, *args)


def _read_file_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def _cache_key(code_text: str, error_msg: str) -> str:
    payload = f"{code_text}\n---\n{error_msg}".encode("utf-8", errors="ignore")
    return hashlib.sha256(payload).hexdigest()


async def _run_debug_pipeline(file_path: Path) -> DebugResponse:
    grand_start = time.time()
    path_text = str(file_path)
    error_msg = await run_in_executor(run_target_code, file_path)

    code_text = ""
    try:
        code_text = await run_in_executor(_read_file_text, file_path)
    except OSError:
        code_text = ""

    if not error_msg:
        complexity_data = None
        security_data = None
        source_payload = code_text if len(code_text) <= MAX_SNIPPET_CHARS else None
        if code_text:
            complexity_data = agents.complexity_agent(code_text)
            security_data = agents.security_audit_agent(code_text)
        return DebugResponse(
            success=True,
            error=None,
            complexity=complexity_data,
            security_audit=security_data,
            total_time=round(time.time() - grand_start, 3),
            source_path=path_text,
            source_code=source_payload,
        )

    try:
        key = _cache_key(code_text, error_msg)
        cached = debug_cache.get(key)
        if cached:
            result = cached.model_copy(deep=True)
            result.total_time = round(time.time() - grand_start, 3)
            metrics = dict(result.metrics or {})
            metrics["cache_status"] = 1.0
            result.metrics = metrics
            result.source_path = path_text
            if result.source_code is None and len(code_text) <= MAX_SNIPPET_CHARS:
                result.source_code = code_text
            return result

        # Phase 1: static extraction, KB lookup, severity/complexity/security.
        p1_start = time.time()
        code_context, local_knowledge, severity, complexity, security_data = await asyncio.gather(
            run_in_executor(scanner.get_context_for_file, path_text),
            run_in_executor(rag.query_docs, error_msg),
            run_in_executor(agents.severity_agent, error_msg),
            run_in_executor(agents.complexity_agent, code_text),
            run_in_executor(agents.security_audit_agent, code_text),
        )
        p1_time = round(time.time() - p1_start, 3)

        if isinstance(code_context, str) and code_context.startswith("Error reading file:"):
            code_context = code_text

        # Phase 2: orchestrated fix.
        p2_start = time.time()
        if agents.llm is None:
            orchestration_result = {
                "success": False,
                "fix": "",
                "reason": "LLM unavailable; install model to generate fixes.",
                "path_taken": "LLM unavailable fallback",
            }
        else:
            workspace_files = await run_in_executor(scanner.scan_workspace)
            orchestration_result = await agents.viper_orchestration(error_msg, code_context, workspace_files)
        p2_time = round(time.time() - p2_start, 3)

        # Phase 3: synthesis + confidence.
        p3_start = time.time()
        fixed_code = orchestration_result.get("fix") or None
        analysis_data = await run_in_executor(agents.multi_agent_pipeline, error_msg, code_context, local_knowledge)
        p3_time = round(time.time() - p3_start, 3)

        confidence = agents.confidence_agent(
            error_msg,
            str(analysis_data.get("analysis", "")),
            fixed_code,
        )
        total_time = round(time.time() - grand_start, 3)

        response = DebugResponse(
            success=False,
            error=error_msg,
            analysis=analysis_data.get("analysis"),
            explanation=analysis_data.get("explanation"),
            verification=orchestration_result.get("path_taken"),
            fixed_code=fixed_code,
            severity=severity,
            confidence=confidence,
            complexity=complexity,
            security_audit=security_data,
            metrics={
                "scan_rag": float(p1_time),
                "viper_orchestration": float(p2_time),
                "final_synthesis": float(p3_time),
            },
            total_time=total_time,
            source_path=path_text,
            source_code=code_text if len(code_text) <= MAX_SNIPPET_CHARS else None,
        )

        debug_cache.set(key, response)
        return response
    except HTTPException:
        raise
    except Exception as exc:
        traceback.print_exc()
        logger.exception("Debug pipeline failed for file %s: %s", path_text, exc)
        raise HTTPException(status_code=500, detail="Debug pipeline failed unexpectedly.") from exc


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    request_id = getattr(request.state, "request_id", str(uuid.uuid4()))
    logger.exception(
        "Unhandled exception request_id=%s method=%s path=%s error=%s",
        request_id,
        request.method,
        request.url.path,
        exc,
    )
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error.", "request_id": request_id},
        headers={"X-Request-ID": request_id},
    )


@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    request_id = getattr(request.state, "request_id", str(uuid.uuid4()))
    detail = exc.detail if isinstance(exc.detail, str) else "Request failed."
    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": detail, "request_id": request_id},
        headers={"X-Request-ID": request_id},
    )


@app.get("/health")
def health_check():
    uptime_seconds = round(time.time() - PROCESS_START_TIME, 2)
    frontend_index = PROJECT_ROOT / "frontend" / "dist" / "index.html"
    return {
        "status": "online",
        "model_loaded": agents.llm is not None,
        "model_path": agents.model_path,
        "workspace_root": str(WORKSPACE_ROOT),
        "frontend_ready": frontend_index.exists(),
        "uptime_seconds": uptime_seconds,
        "rate_limit_per_minute": RATE_LIMIT_PER_MINUTE,
        "engine": "Offline Debugger Pipeline v6.0.0",
    }


@app.post("/debug", response_model=DebugResponse)
async def debug_file(request: DebugRequest):
    file_path = _safe_resolve_workspace_path(request.file_path, must_exist=True, enforce_python=True)
    return await _run_debug_pipeline(file_path)


@app.post("/debug_snippet", response_model=DebugResponse)
async def debug_snippet(request: SnippetRequest):
    if len(request.code) > MAX_SNIPPET_CHARS:
        raise HTTPException(status_code=413, detail=f"Snippet too large. Max {MAX_SNIPPET_CHARS} characters.")

    with tempfile.NamedTemporaryFile(
        mode="w",
        suffix=".py",
        delete=False,
        dir=str(UPLOAD_DIR),
        prefix="_snippet_",
        encoding="utf-8",
    ) as tmp:
        tmp.write(request.code)
        tmp_path = Path(tmp.name)

    try:
        return await _run_debug_pipeline(tmp_path)
    finally:
        if tmp_path.exists():
            tmp_path.unlink(missing_ok=True)


@app.post("/analyze_complexity")
async def analyze_complexity(request: ComplexityRequest):
    return agents.complexity_agent(request.code)


@app.get("/scan_project")
async def scan_project():
    files = scanner.scan_workspace()
    return {"files": files, "count": len(files)}


@app.post("/upload", response_model=DebugResponse)
async def upload_file(file: UploadFile = File(...)):
    safe_name = _safe_upload_name(file.filename)
    payload = await file.read(MAX_UPLOAD_BYTES + 1)
    if len(payload) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail=f"Upload too large. Max {MAX_UPLOAD_BYTES} bytes.")

    file_path = (UPLOAD_DIR / safe_name).resolve()
    try:
        file_path.relative_to(WORKSPACE_ROOT)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="Upload destination is outside workspace.") from exc

    file_path.write_bytes(payload)
    return await _run_debug_pipeline(file_path)


@app.post("/diff")
async def compute_diff(request: DiffRequest):
    orig_lines = request.original.splitlines(keepends=True)
    fixed_lines = request.fixed.splitlines(keepends=True)
    diff = list(
        difflib.unified_diff(
            orig_lines,
            fixed_lines,
            fromfile="original.py",
            tofile="fixed.py",
            lineterm="",
        )
    )
    return {"diff": "".join(diff)}


@app.post("/apply_fix")
async def apply_fix(request: ApplyFixRequest):
    target_path = _safe_resolve_workspace_path(request.file_path, must_exist=False, enforce_python=True)
    target_path.parent.mkdir(parents=True, exist_ok=True)

    clean_code = request.fixed_code.replace("```python", "").replace("```", "").strip()
    if not clean_code:
        raise HTTPException(status_code=400, detail="Fixed code is empty after sanitization.")
    if len(clean_code) > MAX_SNIPPET_CHARS:
        raise HTTPException(status_code=413, detail=f"Fixed code exceeds {MAX_SNIPPET_CHARS} characters.")

    fixed_filename = f"fixed_{target_path.name}"
    full_path = target_path.parent / fixed_filename
    full_path.write_text(clean_code, encoding="utf-8")
    return {"message": f"Fixed file created at {full_path}", "path": str(full_path)}


frontend_path = PROJECT_ROOT / "frontend" / "dist"
if frontend_path.exists():
    assets_path = frontend_path / "assets"
    if assets_path.exists():
        app.mount("/assets", StaticFiles(directory=str(assets_path)), name="assets")

    @app.get("/{rest_of_path:path}")
    async def serve_frontend(rest_of_path: str):
        return FileResponse(str(frontend_path / "index.html"))


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host=HOST, port=PORT)
