from __future__ import annotations

import os
from pathlib import Path
from typing import Any


class CodeScanner:
    def __init__(self, project_path: str):
        self.project_path = Path(project_path).resolve()

    def get_context_for_file(self, target_file: str) -> str:
        """Read a file with UTF-8 fallback handling for robust cross-platform behavior."""
        try:
            return Path(target_file).read_text(encoding="utf-8", errors="replace")
        except Exception as exc:
            return f"Error reading file: {exc}"

    def scan_workspace(self, root_dir: str | None = None) -> list[dict[str, Any]]:
        """Scan workspace for Python files while skipping noisy/untrusted directories."""
        root_path = Path(root_dir).resolve() if root_dir else self.project_path
        excluded_dirs = {
            ".git",
            "__pycache__",
            "venv",
            ".venv",
            "node_modules",
            ".pytest_cache",
            "frontend",
            "uploads",
            "dist",
            "build",
        }

        results: list[dict[str, Any]] = []
        for current_root, dirs, files in os.walk(root_path):
            dirs[:] = [d for d in dirs if d not in excluded_dirs]
            root_obj = Path(current_root)

            for file_name in files:
                file_path = root_obj / file_name
                if file_path.suffix != ".py":
                    continue

                try:
                    stat = file_path.stat()
                    rel_path = file_path.relative_to(root_path)
                    results.append(
                        {
                            "name": file_name,
                            "path": str(file_path),
                            "rel_path": str(rel_path),
                            "size": stat.st_size,
                        }
                    )
                except OSError:
                    continue

        results.sort(key=lambda item: item["rel_path"])
        return results
