from __future__ import annotations

import shutil
import subprocess
import sys
import time
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent
FRONTEND_DIR = PROJECT_ROOT / "frontend"
BACKEND_URL = "http://127.0.0.1:8000/health"


def _wait_for_backend(timeout_seconds: int = 20) -> bool:
    import urllib.request

    start = time.time()
    while time.time() - start < timeout_seconds:
        try:
            with urllib.request.urlopen(BACKEND_URL, timeout=2) as resp:
                if resp.status == 200:
                    return True
        except Exception:
            time.sleep(0.5)
    return False


def _ensure_frontend_prereqs() -> None:
    if not FRONTEND_DIR.exists():
        raise RuntimeError(f"Missing frontend directory: {FRONTEND_DIR}")
    if shutil.which("npm") is None:
        raise RuntimeError("npm was not found in PATH. Install Node.js and npm first.")


def start_services() -> None:
    print("Starting Offline Debugger services...")
    _ensure_frontend_prereqs()

    backend_proc = subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "app:app", "--host", "0.0.0.0", "--port", "8000"],
        cwd=str(PROJECT_ROOT),
    )

    if not _wait_for_backend():
        backend_proc.terminate()
        raise RuntimeError("Backend failed to become healthy within timeout.")

    frontend_proc = subprocess.Popen(
        ["npm", "run", "dev"],
        cwd=str(FRONTEND_DIR),
        shell=False,
    )

    print("=" * 56)
    print("Offline Debugger is running")
    print("Frontend: http://localhost:5173")
    print("Backend:  http://localhost:8000")
    print("Press Ctrl+C to stop both processes")
    print("=" * 56)

    try:
        while True:
            if backend_proc.poll() is not None:
                raise RuntimeError("Backend process exited unexpectedly.")
            if frontend_proc.poll() is not None:
                raise RuntimeError("Frontend process exited unexpectedly.")
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nStopping services...")
    finally:
        for proc in (frontend_proc, backend_proc):
            if proc.poll() is None:
                proc.terminate()
        for proc in (frontend_proc, backend_proc):
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
        print("Shutdown complete.")


if __name__ == "__main__":
    start_services()
